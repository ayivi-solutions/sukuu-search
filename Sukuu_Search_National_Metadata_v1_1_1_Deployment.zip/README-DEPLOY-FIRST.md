# SukuuX Ghana Schools — production deployment package

Target: https://search.sukuux.com/
Build date: 2026-09-03

## Deploy

Upload the **contents of this folder**, preserving the directory structure, to the document root serving `search.sukuux.com`. The root must expose `index.html`, `robots.txt` and `sitemap.xml` directly.

### DNS and HTTPS

1. Create the `search` DNS record for `sukuux.com` as required by the chosen host.
2. Enable a valid TLS certificate and force HTTPS.
3. Ensure every unknown URL returns the included `404.html` with a genuine HTTP 404 status. Do not rewrite every unknown URL to `index.html`.

### Google indexing

1. Add or verify the `sukuux.com` Domain property in Google Search Console using DNS verification.
2. Submit `https://search.sukuux.com/sitemap.xml`.
3. Inspect `https://search.sukuux.com/` and request indexing after deployment.
4. Test representative school, district and region URLs using URL Inspection and the Rich Results Test.
5. Confirm that `robots.txt`, all sitemap files and static pages return HTTP 200.

Google can discover URLs through sitemaps, but submission does not guarantee indexing. The package therefore includes crawlable HTML pages and ordinary `<a href>` links rather than relying only on the JavaScript application.

## Included

- Interactive mobile-first `index.html` with canonical metadata and JSON-LD.
- 10,503 crawlable canonical school profile pages with unique titles, descriptions and School schema; all 10,795 source rows remain in the interactive app.
- 16 regional pages and 261 district pages.
- 43 paginated all-school directory pages.
- Sitemap index plus static, region, district and school sitemaps.
- `robots.txt`, `manifest.webmanifest`, favicon, OpenSearch and `llms.txt`.
- Cloudflare Pages/Netlify `_headers`, Apache `.htaccess`, `CNAME`, 404 page and security contact.
- Browser-optimized ADM0, ADM1 and ADM2 GeoJSON downloads with provenance.

## Important limitation

Most coordinates represent an approximate locality rather than the exact school campus. Preserve the disclaimer wherever the data is reused.
